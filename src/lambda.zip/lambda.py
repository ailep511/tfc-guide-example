import boto3

def lambda_handler(event, context):
# My super Lambda function
    return True